from django.shortcuts import render, HttpResponse, redirect
  # the index function is called when root is visited
def index(request):
    response = "Hello, this is the placeholder to view all blogs!"
    return HttpResponse(response)

# Create your views here.
def new(request):
    response = "Hello, this is the placeholder to create a new blog!"
    return HttpResponse(response)

def create(request):
    return redirect ('/')

def show(request, blog_id):
    print blog_id
    return HttpResponse("placeholder to display blog {}".format(blog_id))

def edit(request, blog_id):
    return HttpResponse("placeholder to edit blog {}".format(blog_id))
    
def delete(request, blog_id):
    return redirect('/')

